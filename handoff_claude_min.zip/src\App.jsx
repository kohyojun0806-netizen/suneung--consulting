import { useState } from "react";

const GRADE_INFO = {
  1: { label: "1등급", color: "#ff5d5d", range: "96~100점" },
  2: { label: "2등급", color: "#ff7b39", range: "89~95점" },
  3: { label: "3등급", color: "#ffad33", range: "77~88점" },
  4: { label: "4등급", color: "#f0cc5f", range: "60~76점" },
  5: { label: "5등급", color: "#87d88b", range: "40~59점" },
  6: { label: "6등급", color: "#6aa7ff", range: "23~39점" },
  7: { label: "7등급", color: "#9b8cff", range: "12~22점" },
  8: { label: "8등급", color: "#a2adb5", range: "4~11점" },
  9: { label: "9등급", color: "#6f7a82", range: "3점 이하" },
};

const ELECTIVES = ["확률과통계", "미적분", "기하"];

export default function App() {
  const [currentGrade, setCurrentGrade] = useState(null);
  const [targetGrade, setTargetGrade] = useState(null);
  const [electiveSubject, setElectiveSubject] = useState("미적분");
  const [plan, setPlan] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const canSubmit = !!currentGrade && !!targetGrade && targetGrade < currentGrade;

  async function handleAnalyze() {
    if (!currentGrade || !targetGrade) {
      setError("현재 등급과 목표 등급을 모두 선택해주세요.");
      return;
    }
    if (targetGrade >= currentGrade) {
      setError("목표 등급은 현재 등급보다 높아야 합니다. (숫자가 작을수록 상위)");
      return;
    }

    setError("");
    setLoading(true);

    try {
      const res = await fetch("http://localhost:8787/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          currentGrade,
          targetGrade,
          electiveSubject,
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data?.error || "분석 중 오류가 발생했습니다.");
      setPlan(data.plan || null);
    } catch (e) {
      setError(e.message || "분석 중 오류가 발생했습니다.");
    } finally {
      setLoading(false);
    }
  }

  function resetAll() {
    setCurrentGrade(null);
    setTargetGrade(null);
    setElectiveSubject("미적분");
    setPlan(null);
    setError("");
  }

  return (
    <div style={s.root}>
      <div style={s.bg} />
      <div style={s.wrap}>
        <header style={s.header}>
          <div style={s.badge}>수능 수학 로드맵</div>
          <h1 style={s.title}>
            과목 구조를 반영한
            <br />
            <span style={s.accent}>등급별 학습 설계</span>
          </h1>
          <p style={s.sub}>공통(수학I/II) + 선택(확통/미적/기하) 기준으로 계획을 제안합니다.</p>
        </header>

        {!plan && (
          <div style={s.card}>
            <Section title="현재 등급">
              <GradeGrid selected={currentGrade} onSelect={setCurrentGrade} disabledFrom={null} />
            </Section>

            <Section title="목표 등급">
              <GradeGrid selected={targetGrade} onSelect={setTargetGrade} disabledFrom={currentGrade} />
            </Section>

            <Section title="선택 과목">
              <div style={s.electiveRow}>
                {ELECTIVES.map((subject) => (
                  <button
                    key={subject}
                    type="button"
                    onClick={() => setElectiveSubject(subject)}
                    style={{
                      ...s.electiveBtn,
                      ...(electiveSubject === subject ? s.electiveBtnOn : null),
                    }}
                  >
                    {subject}
                  </button>
                ))}
              </div>
            </Section>

            {error ? <div style={s.error}>{error}</div> : null}

            <button
              type="button"
              onClick={handleAnalyze}
              disabled={!canSubmit || loading}
              style={{ ...s.cta, opacity: canSubmit && !loading ? 1 : 0.45 }}
            >
              {loading
                ? "분석 중..."
                : currentGrade && targetGrade
                  ? `${currentGrade}등급 → ${targetGrade}등급 분석 시작`
                  : "등급을 선택해주세요"}
            </button>
          </div>
        )}

        {plan && (
          <div style={s.resultWrap}>
            <div style={s.rowBadges}>
              <span style={{ ...s.gradePill, background: GRADE_INFO[currentGrade]?.color }}>{currentGrade}등급</span>
              <span style={s.arrow}>→</span>
              <span style={{ ...s.gradePill, background: GRADE_INFO[targetGrade]?.color }}>{targetGrade}등급</span>
              <span style={s.subjectPill}>선택: {plan.selected_elective || electiveSubject}</span>
            </div>

            <Panel title="현재 수능 수학 체계">
              <p style={s.metaText}>기준일: {plan.math_structure?.as_of}</p>
              <p style={s.body}>유형: {plan.math_structure?.current_csat?.type}</p>
              <p style={s.body}>공통: {(plan.math_structure?.current_csat?.common || []).join(", ")}</p>
              <p style={s.body}>선택: {(plan.math_structure?.current_csat?.elective_options || []).join(", ")}</p>
              <p style={s.body}>규칙: {plan.math_structure?.current_csat?.rule}</p>
              <p style={s.warnText}>
                참고: {plan.math_structure?.note_2028?.effective_exam_year} {plan.math_structure?.note_2028?.summary}
              </p>
            </Panel>

            <Panel title="학생 맞춤 피드백">
              <p style={s.body}>{plan.student_feedback}</p>
            </Panel>

            <Panel title="지금 시기 핵심 공부">
              <h3 style={s.focusHeadline}>{plan.current_focus?.headline}</h3>
              <p style={s.body}>{plan.current_focus?.why_now}</p>
              <List items={plan.current_focus?.actions} />
              <p style={s.metaText}>하루 루틴: {plan.current_focus?.daily_plan}</p>
              <p style={s.warnText}>주의: {plan.current_focus?.caution}</p>
            </Panel>

            <Panel title="모평 구간별 계획">
              <div style={s.periodGrid}>
                {(plan.period_plan || []).map((period, idx) => (
                  <div key={`${period.period}-${idx}`} style={s.periodCard}>
                    <div style={s.periodTitle}>{period.period}</div>
                    <p style={s.metaText}>목표: {period.goal}</p>
                    <List items={period.actions} />
                    <div style={s.smallTitle}>체크포인트</div>
                    <List items={period.checkpoints} />
                    <p style={s.warnText}>주의: {period.caution}</p>
                  </div>
                ))}
              </div>
            </Panel>

            <Panel title="강사별 과목 커리큘럼">
              <div style={s.itemList}>
                {(plan.subject_curriculum || []).map((teacher, idx) => (
                  <div key={`${teacher.name}-${idx}`} style={s.itemCardLarge}>
                    <div style={s.itemHeader}>
                      <strong>{teacher.name}</strong>
                      <span style={s.platform}>{teacher.platform}</span>
                    </div>

                    <div style={s.smallTitle}>수학I</div>
                    <List items={teacher.common_subjects?.["수학I"]} />

                    <div style={s.smallTitle}>수학II</div>
                    <List items={teacher.common_subjects?.["수학II"]} />

                    <div style={s.smallTitle}>{teacher.elective_subject?.subject}</div>
                    <List items={teacher.elective_subject?.strategy} />

                    <div style={s.smallTitle}>선택과목 체크포인트</div>
                    <List items={teacher.elective_subject?.checkpoints} />
                  </div>
                ))}
              </div>
            </Panel>

            <div style={s.twoCol}>
              <Panel title="추천 강사" compact>
                <div style={s.itemList}>
                  {(plan.recommended_instructors || []).map((item, idx) => (
                    <div key={`${item.name}-${idx}`} style={s.itemCard}>
                      <div style={s.itemHeader}>
                        <strong>{item.name}</strong>
                        <span style={s.platform}>{item.platform}</span>
                      </div>
                      <p style={s.itemText}>적합 학생: {item.best_for}</p>
                      <p style={s.itemText}>추천 이유: {item.reason}</p>
                      <p style={s.itemText}>활용법: {item.usage}</p>
                    </div>
                  ))}
                </div>
              </Panel>

              <Panel title="추천 교재" compact>
                <div style={s.itemList}>
                  {(plan.recommended_books || []).map((item, idx) => (
                    <div key={`${item.title}-${idx}`} style={s.itemCard}>
                      <div style={s.itemHeader}>
                        <strong>{item.title}</strong>
                        <span style={s.platform}>{item.type}</span>
                      </div>
                      <p style={s.itemText}>목적: {item.purpose}</p>
                      <p style={s.itemText}>권장 시기: {item.when_to_use}</p>
                      <p style={s.itemText}>난이도: {item.difficulty}</p>
                    </div>
                  ))}
                </div>
              </Panel>
            </div>

            <Panel title="마무리 조언">
              <p style={s.body}>{plan.final_tip}</p>
            </Panel>

            <button type="button" onClick={resetAll} style={s.resetBtn}>
              다시 설정하기
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

function Section({ title, children }) {
  return (
    <section style={{ marginBottom: 24 }}>
      <h2 style={s.sectionTitle}>{title}</h2>
      {children}
    </section>
  );
}

function Panel({ title, children, compact = false }) {
  return (
    <section style={{ ...s.panel, padding: compact ? 16 : 20 }}>
      <h2 style={s.panelTitle}>{title}</h2>
      {children}
    </section>
  );
}

function List({ items }) {
  const arr = Array.isArray(items) ? items : [];
  if (!arr.length) return null;
  return (
    <ul style={s.ul}>
      {arr.map((item, i) => (
        <li key={`${item}-${i}`} style={s.li}>{item}</li>
      ))}
    </ul>
  );
}

function GradeGrid({ selected, onSelect, disabledFrom }) {
  return (
    <div style={s.grid}>
      {Object.entries(GRADE_INFO).map(([grade, info]) => {
        const n = Number(grade);
        const disabled = disabledFrom ? n >= disabledFrom : false;
        return (
          <button
            key={grade}
            type="button"
            onClick={() => !disabled && onSelect(n)}
            style={{
              ...s.gradeBtn,
              background: selected === n ? info.color : "rgba(255,255,255,0.05)",
              borderColor: selected === n ? info.color : "rgba(255,255,255,0.14)",
              color: selected === n ? "#fff" : disabled ? "#4f5663" : "#c4c4c4",
              opacity: disabled ? 0.35 : 1,
            }}
          >
            <span style={{ fontWeight: 700 }}>{info.label}</span>
            <span style={{ fontSize: 11, opacity: 0.8 }}>{info.range}</span>
          </button>
        );
      })}
    </div>
  );
}

const s = {
  root: {
    minHeight: "100vh",
    color: "#f3f3f3",
    background: "#070b14",
    fontFamily: "'Pretendard','Noto Sans KR','Malgun Gothic',sans-serif",
    position: "relative",
  },
  bg: {
    position: "fixed",
    inset: 0,
    background:
      "radial-gradient(circle at 20% 20%, rgba(255,109,109,0.14), transparent 36%), radial-gradient(circle at 80% 70%, rgba(87,155,255,0.14), transparent 36%), linear-gradient(rgba(255,255,255,0.03) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.03) 1px, transparent 1px)",
    backgroundSize: "auto, auto, 38px 38px, 38px 38px",
    pointerEvents: "none",
  },
  wrap: {
    width: "min(980px, 92vw)",
    margin: "0 auto",
    padding: "34px 0 72px",
    position: "relative",
    zIndex: 1,
  },
  header: { textAlign: "center", marginBottom: 26 },
  badge: {
    display: "inline-block",
    border: "1px solid rgba(255,127,127,0.45)",
    background: "rgba(255,127,127,0.15)",
    color: "#ff8b8b",
    padding: "5px 12px",
    borderRadius: 999,
    fontSize: 12,
    marginBottom: 12,
  },
  title: { margin: 0, fontSize: "clamp(26px, 4vw, 44px)", lineHeight: 1.25, letterSpacing: -0.5 },
  accent: {
    background: "linear-gradient(135deg,#ff8a6a,#6cb0ff)",
    WebkitBackgroundClip: "text",
    WebkitTextFillColor: "transparent",
  },
  sub: { color: "#94a0b3", marginTop: 12, fontSize: 14 },
  card: {
    background: "rgba(255,255,255,0.04)",
    border: "1px solid rgba(255,255,255,0.12)",
    borderRadius: 18,
    padding: 22,
    backdropFilter: "blur(8px)",
  },
  sectionTitle: { margin: "0 0 10px", fontSize: 14, color: "#9aa5b8" },
  grid: { display: "grid", gridTemplateColumns: "repeat(3, minmax(0,1fr))", gap: 8 },
  gradeBtn: {
    border: "1px solid",
    borderRadius: 12,
    padding: "10px 6px",
    display: "flex",
    flexDirection: "column",
    gap: 4,
    alignItems: "center",
    transition: "all .16s",
    cursor: "pointer",
  },
  electiveRow: { display: "grid", gridTemplateColumns: "repeat(3, minmax(0,1fr))", gap: 8 },
  electiveBtn: {
    border: "1px solid rgba(255,255,255,0.14)",
    borderRadius: 10,
    background: "rgba(255,255,255,0.04)",
    color: "#c8d1e2",
    padding: "10px 12px",
    cursor: "pointer",
    fontWeight: 600,
  },
  electiveBtnOn: {
    border: "1px solid rgba(108,176,255,0.7)",
    background: "rgba(108,176,255,0.16)",
    color: "#d7e7ff",
  },
  error: {
    marginBottom: 10,
    padding: "10px 12px",
    borderRadius: 10,
    border: "1px solid rgba(255,100,100,0.4)",
    background: "rgba(255,100,100,0.12)",
    color: "#ff8e8e",
    fontSize: 13,
  },
  cta: {
    width: "100%",
    border: "none",
    borderRadius: 12,
    padding: "14px 16px",
    background: "linear-gradient(135deg,#ff7f66,#ff4f7a)",
    color: "#fff",
    fontWeight: 700,
    fontSize: 15,
    cursor: "pointer",
  },
  resultWrap: { display: "grid", gap: 12 },
  rowBadges: { display: "flex", alignItems: "center", gap: 8, marginBottom: 4, flexWrap: "wrap" },
  gradePill: { borderRadius: 999, padding: "4px 12px", fontWeight: 700, fontSize: 13 },
  subjectPill: {
    borderRadius: 999,
    padding: "4px 12px",
    fontWeight: 700,
    fontSize: 13,
    background: "rgba(108,176,255,0.2)",
    border: "1px solid rgba(108,176,255,0.45)",
    color: "#d7e7ff",
  },
  arrow: { color: "#8f98aa" },
  panel: {
    background: "rgba(255,255,255,0.05)",
    border: "1px solid rgba(255,255,255,0.11)",
    borderRadius: 14,
  },
  panelTitle: { margin: "0 0 10px", fontSize: 15, color: "#ffba8b" },
  focusHeadline: { margin: "0 0 8px", fontSize: 17 },
  body: { margin: "0 0 8px", lineHeight: 1.7, color: "#d9deea", fontSize: 14 },
  metaText: { margin: "0 0 8px", color: "#a9b4c6", fontSize: 13, lineHeight: 1.65 },
  warnText: { margin: 0, color: "#ffb47e", fontSize: 13, lineHeight: 1.65 },
  periodGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))",
    gap: 10,
  },
  periodCard: {
    border: "1px solid rgba(255,255,255,0.11)",
    background: "rgba(11,17,30,0.45)",
    borderRadius: 12,
    padding: 12,
  },
  periodTitle: { fontWeight: 800, marginBottom: 7, color: "#83b5ff" },
  smallTitle: { marginTop: 8, marginBottom: 4, fontSize: 12, color: "#8da0bf", fontWeight: 700 },
  ul: { margin: "0 0 8px", paddingLeft: 18 },
  li: { marginBottom: 4, lineHeight: 1.6, color: "#d6deee", fontSize: 13 },
  twoCol: { display: "grid", gap: 12, gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))" },
  itemList: { display: "grid", gap: 8 },
  itemCardLarge: {
    background: "rgba(255,255,255,0.04)",
    border: "1px solid rgba(255,255,255,0.1)",
    borderRadius: 10,
    padding: 12,
  },
  itemCard: {
    background: "rgba(255,255,255,0.04)",
    border: "1px solid rgba(255,255,255,0.1)",
    borderRadius: 10,
    padding: 10,
  },
  itemHeader: { display: "flex", justifyContent: "space-between", alignItems: "center", gap: 8, marginBottom: 6, fontSize: 14 },
  platform: {
    fontSize: 11,
    color: "#8fb3ff",
    border: "1px solid rgba(125,165,255,0.35)",
    borderRadius: 999,
    padding: "2px 8px",
  },
  itemText: { margin: "0 0 4px", color: "#c8d3e6", fontSize: 12.5, lineHeight: 1.55 },
  resetBtn: {
    border: "1px solid rgba(255,255,255,0.18)",
    background: "rgba(255,255,255,0.03)",
    color: "#c2ccdf",
    borderRadius: 12,
    padding: "12px 14px",
    cursor: "pointer",
    fontSize: 14,
  },
};
